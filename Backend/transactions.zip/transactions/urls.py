from django.urls import path
from .views import TransactionViewSet


transaction_list = TransactionViewSet.as_view({
    'get': 'list',
    'post': 'create',
})

transaction_detail = TransactionViewSet.as_view({
    'get': 'retrieve',
    'put': 'update',
    'patch': 'partial_update',
    'delete': 'destroy',
})


urlpatterns = [
    path('transactions/', transaction_list),
    path('transactions/<int:pk>/', transaction_detail),
]